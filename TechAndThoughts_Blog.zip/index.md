---
layout: home
title: "Home"
---

# Welcome to Tech & Thoughts 💻
A dark-themed blog by **CipherLurk**, where I share insights on cybersecurity, tech projects, and more.
