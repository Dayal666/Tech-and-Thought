---
layout: post
title: "Welcome to Tech & Thoughts"
date: 2025-11-03
categories: [cybersecurity, tech-projects]
---

Hello world! 👋  
Welcome to my blog — *Tech & Thoughts*. Here I’ll share my experiments, discoveries, and thoughts from the world of cybersecurity and technology.

Stay tuned for deep dives, walkthroughs, and raw terminal energy ⚡
