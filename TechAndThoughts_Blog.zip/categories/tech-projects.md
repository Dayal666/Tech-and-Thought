---
layout: category
title: "Tech Projects"
category: tech-projects
permalink: /category/tech-projects/
---
